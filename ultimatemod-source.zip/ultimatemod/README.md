# Ultimate Mod (Fabric 1.21.11)
Build: install Java 21 + Gradle 9.2+, then run `gradle build`.
Jar: build/libs/ultimatemod-1.0.0.jar -> put into the mods folder with Fabric API.
No PC? Push this folder to GitHub -> Actions -> "build" -> download the artifact.
