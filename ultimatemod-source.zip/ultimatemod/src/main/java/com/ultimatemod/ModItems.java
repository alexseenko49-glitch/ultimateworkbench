package com.ultimatemod;

import java.util.function.Function;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class ModItems {
	public static final Item OBSIDIAN_INGOT = register("obsidian_ingot", Item::new, new Item.Properties());
	public static final Item IRON_STICK = register("iron_stick", Item::new, new Item.Properties());
	public static final Item OBSIDIAN_PICKAXE = register("obsidian_pickaxe", Item::new,
			new Item.Properties().pickaxe(ModToolMaterials.OBSIDIAN, 1.0F, -2.8F));

	private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, UltimateMod.id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
	}

	public static void init() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(e -> {
			e.accept(OBSIDIAN_INGOT);
			e.accept(IRON_STICK);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(e -> e.accept(OBSIDIAN_PICKAXE));
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FUNCTIONAL_BLOCKS).register(e -> e.accept(ModBlocks.ULTIMATE_WORKBENCH_ITEM));
	}
}
