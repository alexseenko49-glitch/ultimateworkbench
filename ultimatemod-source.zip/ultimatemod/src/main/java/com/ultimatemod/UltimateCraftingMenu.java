package com.ultimatemod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Vanilla crafting menu + extra recipes that work ONLY here.
 * Slots: 0 = result, 1..9 = grid (row by row: 1,2,3 = top row A; 4,5,6 = B; 7,8,9 = C).
 */
public class UltimateCraftingMenu extends CraftingMenu {
	private final ContainerLevelAccess ultimateAccess;
	private final Player ultimatePlayer;

	public UltimateCraftingMenu(int containerId, Inventory inventory, ContainerLevelAccess access) {
		super(containerId, inventory, access);
		this.ultimateAccess = access;
		this.ultimatePlayer = inventory.player;
	}

	@Override
	public boolean stillValid(Player player) {
		return AbstractContainerMenu.stillValid(ultimateAccess, player, ModBlocks.ULTIMATE_WORKBENCH);
	}

	@Override
	public void slotsChanged(Container container) {
		super.slotsChanged(container);
		if (!(ultimatePlayer instanceof ServerPlayer)) {
			return;
		}
		if (matchesObsidianPickaxe()) {
			getSlot(0).set(new ItemStack(ModItems.OBSIDIAN_PICKAXE));
			broadcastChanges();
		}
	}

	/** A1 A2 A3 = Obsidian Ingot, B2 = Iron Stick, C2 = Iron Stick, everything else empty. */
	private boolean matchesObsidianPickaxe() {
		for (int i = 1; i <= 9; i++) {
			ItemStack stack = getSlot(i).getItem();
			Item expected = switch (i) {
				case 1, 2, 3 -> ModItems.OBSIDIAN_INGOT;
				case 5, 8 -> ModItems.IRON_STICK;
				default -> null;
			};
			if (expected == null ? !stack.isEmpty() : !stack.is(expected)) {
				return false;
			}
		}
		return true;
	}
}
