package com.ultimatemod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CraftingTableBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Same as a normal crafting table, but opens a menu that also knows the Ultimate-only recipes. */
public class UltimateWorkbenchBlock extends CraftingTableBlock {
	private static final Component TITLE = Component.translatable("block.ultimatemod.ultimate_workbench");

	public UltimateWorkbenchBlock(Properties properties) {
		super(properties);
	}

	@Override
	protected MenuProvider getMenuProvider(BlockState state, Level level, BlockPos pos) {
		return new SimpleMenuProvider(
				(id, inventory, player) -> new UltimateCraftingMenu(id, inventory, ContainerLevelAccess.create(level, pos)),
				TITLE);
	}
}
