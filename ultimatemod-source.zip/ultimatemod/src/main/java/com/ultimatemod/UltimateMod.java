package com.ultimatemod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class UltimateMod implements ModInitializer {
	public static final String MOD_ID = "ultimatemod";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.init();
		ModItems.init();
	}
}
