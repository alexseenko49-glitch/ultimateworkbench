package com.ultimatemod;

import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

public class ModToolMaterials {
	public static final TagKey<Item> REPAIRS_OBSIDIAN_TOOL =
			TagKey.create(Registries.ITEM, UltimateMod.id("repairs_obsidian_tool"));

	// incorrect blocks tag, durability, speed, attack damage bonus, enchantability, repair items
	public static final ToolMaterial OBSIDIAN = new ToolMaterial(
			BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2000, 8.5F, 3.5F, 15, REPAIRS_OBSIDIAN_TOOL);
}
