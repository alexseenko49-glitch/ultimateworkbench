package com.ultimatemod;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class ModBlocks {
	public static Item ULTIMATE_WORKBENCH_ITEM;
	public static final Block ULTIMATE_WORKBENCH = registerWithItem("ultimate_workbench");

	private static Block registerWithItem(String name) {
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, UltimateMod.id(name));
		Block block = new UltimateWorkbenchBlock(
				BlockBehaviour.Properties.ofFullCopy(Blocks.CRAFTING_TABLE).setId(blockKey));
		Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, UltimateMod.id(name));
		ULTIMATE_WORKBENCH_ITEM = Registry.register(BuiltInRegistries.ITEM, itemKey,
				new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescription()));
		return block;
	}

	public static void init() {
	}
}
